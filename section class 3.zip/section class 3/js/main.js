$(document).ready(function() {
    $('.vedio-play-btn').magnificPopup({
        type:'video'
    });
  });